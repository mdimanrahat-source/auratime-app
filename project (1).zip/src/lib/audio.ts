
export const ALARM_PRESETS: Record<string, { label: string; freq: number; type: OscillatorType }> = {
  "1": { label: "Zenith Melodies", freq: 440, type: "sine" },
  "2": { label: "Cosmic Awakening", freq: 528, type: "triangle" },
  "3": { label: "Gentle Chimes", freq: 660, type: "sine" },
  "4": { label: "Forest Birds Ambient", freq: 784, type: "sine" },
  "5": { label: "Sunrise Symphony", freq: 330, type: "triangle" },
  "6": { label: "Ocean Waves Serenade", freq: 220, type: "sine" },
  "7": { label: "Digital Echoes", freq: 880, type: "square" },
  "8": { label: "Celestial Dream", freq: 432, type: "sine" },
  "9": { label: "Quartz Pulse", freq: 587, type: "square" },
  "10": { label: "Elegant Harp", freq: 349, type: "triangle" },
  "11": { label: "Nebula Whistle", freq: 987, type: "sine" },
  "12": { label: "Futuristic Horizon", freq: 293, type: "sawtooth" },
  "13": { label: "Morning Aura", freq: 392, type: "sine" },
  "14": { label: "Golden Hour", freq: 494, type: "triangle" },
  "15": { label: "Silent Valley", freq: 261, type: "sine" },
  "16": { label: "Deep Focus Resonance", freq: 196, type: "sine" },
  "17": { label: "Solar Flare Pulse", freq: 698, type: "square" },
  "18": { label: "Ethereal Raindrops", freq: 830, type: "sine" },
  "19": { label: "Cyberpunk Dawn", freq: 247, type: "sawtooth" },
  "20": { label: "Infinite Serenity", freq: 554, type: "sine" }
};

export function playAudioTone(id: string, onEnd?: () => void) {
  if (typeof window === 'undefined') return;
  
  // Trigger powerful vibration haptics
  if ("vibrate" in navigator) {
    navigator.vibrate([500, 250, 500, 250, 500, 250, 500]);
  }

  const preset = ALARM_PRESETS[id] || ALARM_PRESETS["1"];
  const Ctx = window.AudioContext || (window as any).webkitAudioContext;
  const ctx = new Ctx();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  
  osc.frequency.value = preset.freq;
  osc.type = preset.type;
  
  // MAX VOLUME: Set gain to absolute maximum for audibility
  gain.gain.setValueAtTime(0, ctx.currentTime);
  gain.gain.linearRampToValueAtTime(1.0, ctx.currentTime + 0.05); // Rapid volume ramp
  
  osc.connect(gain).connect(ctx.destination);
  osc.start();

  const stop = () => {
    try {
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5); // Smoother fade out when manually stopped
      setTimeout(() => { 
        osc.stop(); 
        ctx.close(); 
        onEnd?.(); 
      }, 500);
    } catch (e) {}
  };
  
  // Alarm persists for 30 seconds if not acknowledged
  const timeoutId = setTimeout(stop, 30000);
  
  return () => {
    clearTimeout(timeoutId);
    stop();
  };
}

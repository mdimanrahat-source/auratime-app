'use server';
/**
 * @fileOverview A Genkit flow for setting an alarm from a natural language prompt.
 *
 * - setAlarmFromNaturalLanguage - A function that handles the process of extracting alarm details from text.
 * - SetAlarmFromNaturalLanguageInput - The input type for the setAlarmFromNaturalLanguage function.
 * - SetAlarmFromNaturalLanguageOutput - The return type for the setAlarmFromNaturalLanguage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SetAlarmFromNaturalLanguageInputSchema = z.object({
  naturalLanguagePrompt: z
    .string()
    .describe('A natural language prompt for setting an alarm, e.g., "set an alarm for 7 AM labeled morning reminder with Cosmic Awakening sound".'),
});
export type SetAlarmFromNaturalLanguageInput = z.infer<typeof SetAlarmFromNaturalLanguageInputSchema>;

const SetAlarmFromNaturalLanguageOutputSchema = z.object({
  time: z.string().regex(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/).describe('The time for the alarm in HH:mm format (24-hour).'),
  label: z.string().describe('A descriptive label for the alarm. Defaults to an empty string if not specified.').default(''),
  sound: z.string().optional().describe('The ID of the chosen alarm sound from the available presets. Defaults to "1" if not specified.').default('1'),
});
export type SetAlarmFromNaturalLanguageOutput = z.infer<typeof SetAlarmFromNaturalLanguageOutputSchema>;

// Available sound presets for the LLM to choose from.
const PRESET_SOUNDS = {
  "1": "Zenith Melodies",
  "2": "Cosmic Awakening",
  "3": "Gentle Chimes",
  "4": "Forest Birds Ambient",
  "5": "Sunrise Symphony",
  "6": "Ocean Waves Serenade",
  "7": "Digital Echoes",
  "8": "Celestial Dream",
  "9": "Quartz Pulse",
  "10": "Elegant Harp",
  "11": "Nebula Whistle",
  "12": "Futuristic Horizon",
  "13": "Morning Aura",
  "14": "Golden Hour",
  "15": "Silent Valley",
  "16": "Deep Focus Resonance",
  "17": "Solar Flare Pulse",
  "18": "Ethereal Raindrops",
  "19": "Cyberpunk Dawn",
  "20": "Infinite Serenity"
};

export async function setAlarmFromNaturalLanguage(input: SetAlarmFromNaturalLanguageInput): Promise<SetAlarmFromNaturalLanguageOutput> {
  return setAlarmFromNaturalLanguageFlow(input);
}

const prompt = ai.definePrompt({
  name: 'setAlarmFromNaturalLanguagePrompt',
  input: { schema: SetAlarmFromNaturalLanguageInputSchema },
  output: { schema: SetAlarmFromNaturalLanguageOutputSchema },
  prompt: `You are an Intelligent Temporal Assistant. Your task is to parse a natural language request and extract the details for setting an alarm.

Today's date is {{currentDate}}.

When extracting the time, always assume the closest future occurrence. If no specific time is mentioned (e.g., 
'use server';
/**
 * @fileOverview A Genkit flow for setting a timer from a natural language prompt.
 *
 * - setTimerFromNaturalLanguage - A function that handles parsing a natural language prompt to set a timer.
 * - SetTimerFromNaturalLanguageInput - The input type for the setTimerFromNaturalLanguage function.
 * - SetTimerFromNaturalLanguageOutput - The return type for the setTimerFromNaturalLanguage function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SetTimerFromNaturalLanguageInputSchema = z.object({
  text: z
    .string()
    .describe('The natural language prompt for setting a timer.'),
});
export type SetTimerFromNaturalLanguageInput = z.infer<
  typeof SetTimerFromNaturalLanguageInputSchema
>;

const SetTimerFromNaturalLanguageOutputSchema = z.object({
  durationSeconds: z
    .number()
    .describe(
      'The total duration of the timer in seconds, extracted from the prompt.'
    ),
});
export type SetTimerFromNaturalLanguageOutput = z.infer<
  typeof SetTimerFromNaturalLanguageOutputSchema
>;

export async function setTimerFromNaturalLanguage(
  input: SetTimerFromNaturalLanguageInput
): Promise<SetTimerFromNaturalLanguageOutput> {
  return setTimerFromNaturalLanguageFlow(input);
}

const setTimerPrompt = ai.definePrompt({
  name: 'setTimerPrompt',
  input: {schema: SetTimerFromNaturalLanguageInputSchema},
  output: {schema: SetTimerFromNaturalLanguageOutputSchema},
  prompt: `Extract the total duration in seconds from the following text.
If no specific duration is mentioned, assume a default of 300 seconds (5 minutes).
If multiple durations are mentioned, use the last one specified.
Handle common phrasing like "half an hour", "a quarter of an hour", "a few minutes", etc.
Provide the output as a JSON object with a single key 'durationSeconds'.

Example prompts and expected outputs:
- "Set a timer for 10 minutes" -> {"durationSeconds": 600}
- "Start a 30 second timer" -> {"durationSeconds": 30}
- "Timer for 1 hour and 15 minutes" -> {"durationSeconds": 4500}
- "Set a timer for half an hour" -> {"durationSeconds": 1800}
- "Set a timer." -> {"durationSeconds": 300}

User prompt: {{{text}}}`,
});

const setTimerFromNaturalLanguageFlow = ai.defineFlow(
  {
    name: 'setTimerFromNaturalLanguageFlow',
    inputSchema: SetTimerFromNaturalLanguageInputSchema,
    outputSchema: SetTimerFromNaturalLanguageOutputSchema,
  },
  async input => {
    const {output} = await setTimerPrompt(input);
    return output!;
  }
);

'use server';
/**
 * @fileOverview This file implements a Genkit flow for setting an alarm with a custom sound and label
 * based on a natural language input.
 *
 * - setAlarmWithCustomSoundAndLabel - A function that handles the alarm setting process.
 * - SetAlarmInput - The input type for the setAlarmWithCustomSoundAndLabel function.
 * - SetAlarmOutput - The return type for the setAlarmWithCustomSoundAndLabel function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const PRESETS_LIST = `
Available sound tones (ID: Label):
1: Zenith Melodies
2: Cosmic Awakening
3: Gentle Chimes
4: Forest Birds Ambient
5: Sunrise Symphony
6: Ocean Waves Serenade
7: Digital Echoes
8: Celestial Dream
9: Quartz Pulse
10: Elegant Harp
11: Nebula Whistle
12: Futuristic Horizon
13: Morning Aura
14: Golden Hour
15: Silent Valley
16: Deep Focus Resonance
17: Solar Flare Pulse
18: Ethereal Raindrops
19: Cyberpunk Dawn
20: Infinite Serenity
`;

const SetAlarmInputSchema = z.object({
  userRequest: z.string().describe('The user\'s natural language request to set an alarm.'),
});
export type SetAlarmInput = z.infer<typeof SetAlarmInputSchema>;

const SetAlarmOutputSchema = z.object({
  time: z.string().regex(/^([01]\d|2[0-3]):([0-5]\d)$/).describe('The alarm time in HH:MM format (24-hour).'),
  label: z.string().optional().describe('A descriptive label for the alarm.'),
  soundId: z.string().default('1').describe('The ID of the pre-defined sound tone from the available presets (1-20). Defaults to "1" if not specified.'),
});
export type SetAlarmOutput = z.infer<typeof SetAlarmOutputSchema>;

export async function setAlarmWithCustomSoundAndLabel(input: SetAlarmInput): Promise<SetAlarmOutput> {
  return setAlarmWithCustomSoundAndLabelFlow(input);
}

const prompt = ai.definePrompt({
  name: 'setAlarmWithCustomSoundAndLabelPrompt',
  input: { schema: SetAlarmInputSchema },
  output: { schema: SetAlarmOutputSchema },
  prompt: `You are an intelligent temporal assistant for the AuraTime application. Your task is to parse a user's natural language request to set an alarm.

Extract the alarm time, a descriptive label, and a sound tone from the following user request.

- The alarm time must be in HH:MM format (24-hour).
- If a sound tone is not explicitly specified or recognized, default to '1'.
- If no label is specified, leave the 'label' field empty.
- When selecting a sound, choose the best match from the list below based on the user's description. Use the sound ID, not the label.

${PRESETS_LIST}

User request: {{{userRequest}}}`,
});

const setAlarmWithCustomSoundAndLabelFlow = ai.defineFlow(
  {
    name: 'setAlarmWithCustomSoundAndLabelFlow',
    inputSchema: SetAlarmInputSchema,
    outputSchema: SetAlarmOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);

import { config } from 'dotenv';
config();

import '@/ai/flows/set-timer-from-natural-language-flow.ts';
import '@/ai/flows/set-alarm-from-natural-language.ts';
import '@/ai/flows/set-alarm-with-custom-sound-and-label-flow.ts';